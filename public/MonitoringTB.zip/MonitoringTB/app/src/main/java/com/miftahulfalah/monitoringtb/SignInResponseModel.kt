package com.miftahulfalah.monitoringtb

data class SignInResponseModel(val code:Int,
                     val status:String,
                     val message:String)