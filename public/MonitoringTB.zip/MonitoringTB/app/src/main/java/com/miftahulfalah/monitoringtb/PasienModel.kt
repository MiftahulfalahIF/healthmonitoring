package com.miftahulfalah.monitoringtb

data class PasienModel(
    val id : Int,
    val nama : String,
    val email : String,
    val alamat : String,
    val nik : String,
    val no_rekam_medis : String,
    val status : String,
    val jenis_kelamin : String,
    val wanita_subur : String,
    val nama_pmo : String,
    val nik_pmo : String,
    val telepon_pmo : String
)