package com.miftahulfalah.monitoringtb

import android.content.Context
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_monitoring.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MonitoringActivity : AppCompatActivity() {

    lateinit var sp : SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_monitoring)

        sp = applicationContext.getSharedPreferences("monitoringtb", Context.MODE_PRIVATE)
        val email = sp.getString("pasien_email", "")

        val retrofit = Retrofit.Builder()
            .baseUrl("https://mila.gherdianto.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val pas = retrofit.create(NetworkServices::class.java)

        pas.getMonitoringnData(email).enqueue(object : Callback<MonitoringModel>{
            override fun onFailure(call: Call<MonitoringModel>, t: Throwable) {
                runOnUiThread {
                    Toast.makeText(applicationContext, "Gagal mendownload data monitoring", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call<MonitoringModel>, response: Response<MonitoringModel>) {
                val monitoring = response.body()


                if(monitoring?.nama==null){
                    data_con.visibility = View.GONE
                    no_data.visibility = View.VISIBLE
                }else{
                    txt_nama.text = monitoring?.nama
                    txt_no_monitoring.text = monitoring?.no_monitoring
                    txt_dok_konsultan.text = monitoring?.dok_konsultan
                    txt_klinik.text = monitoring?.klinik_awal
                    txt_tgl_mulai.text = monitoring?.tgl_mulai
                    txt_tahap.text = monitoring?.tahap.toString()
                    txt_jumlah_kontrol.text = monitoring?.jumlah_kontrol.toString()
                    txt_status.text = monitoring?.status
                }

            }

        })

    }
}
