package com.miftahulfalah.monitoringtb

import retrofit2.Call
import retrofit2.http.*

interface NetworkServices {

    @FormUrlEncoded
    @POST("api/signin")
    fun signIn(@Field("email") email: String, @Field("password") password: String) : Call<SignInResponseModel>

    @GET("api/pasien/{email}")
    fun getPasienData(@Path("email") email: String) : Call<PasienModel>

    @GET("api/monitoring/{email}")
    fun getMonitoringnData(@Path("email") email: String) : Call<MonitoringModel>
}