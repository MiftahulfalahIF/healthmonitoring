package com.miftahulfalah.monitoringtb

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    lateinit var sp : SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sp = applicationContext.getSharedPreferences("monitoringtb", Context.MODE_PRIVATE)
        val email = sp.getString("pasien_email", "")

        val retrofit = Retrofit.Builder()
            .baseUrl("https://mila.gherdianto.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val pas = retrofit.create(NetworkServices::class.java)
        pas.getPasienData(email).enqueue(object : Callback<PasienModel>{
            override fun onFailure(call: Call<PasienModel>, t: Throwable) {
                runOnUiThread {
                    Toast.makeText(applicationContext, "Gagal mendownload data pasien", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call<PasienModel>, response: Response<PasienModel>) {
                val pasien = response.body()

                txt_nama.text = pasien?.nama
                txt_email.text = pasien?.email
                txt_alamat.text = pasien?.alamat
                txt_jenis_kelamin.text = pasien?.jenis_kelamin
                txt_nama_pmo.text = pasien?.nama_pmo
                txt_nik.text = pasien?.nik
                txt_nik_pmo.text = pasien?.nik_pmo
                txt_telepon_pmo.text = pasien?.telepon_pmo
                txt_no_rekam_medis.text = pasien?.no_rekam_medis
                txt_status.text = pasien?.status
                txt_wanita_subur.text = pasien?.wanita_subur
            }

        })

        monitoring_btn.setOnClickListener {
            val monitoringActivity = Intent(applicationContext, MonitoringActivity::class.java)
            startActivity(monitoringActivity)
        }
    }
}
