package com.miftahulfalah.monitoringtb

data class MonitoringModel(
    val id : Int,
    val nama : String,
    val no_monitoring : String,
    val dok_konsultan : String,
    val klinik_awal : String,
    val tgl_mulai : String,
    val tahap : Int,
    val jumlah_kontrol : Int,
    val status : String
)