package com.miftahulfalah.monitoringtb

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_login.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        login_btn.setOnClickListener {
            /*
            val mainActivity = Intent(applicationContext, MainActivity::class.java)
            startActivity(mainActivity)
            finish()
            */
            login()
        }
    }

    fun login() {
        val email = email_text.text.toString()
        val password = password_text.text.toString()

        val retrofit = Retrofit.Builder()
            .baseUrl("https://mila.gherdianto.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val sis = retrofit.create(NetworkServices::class.java)

        val sisResponse = sis.signIn(email, password)
        sisResponse.enqueue(object : Callback<SignInResponseModel>{
            override fun onFailure(call: Call<SignInResponseModel>, t: Throwable) {
                runOnUiThread {
                    Toast.makeText(applicationContext, "Tidak dapat melakukan login", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call<SignInResponseModel>, response: Response<SignInResponseModel>) {
                if(response.body()!!.code==200) {
                    runOnUiThread {
                        Toast.makeText(applicationContext, "Berhasil login", Toast.LENGTH_SHORT).show()
                    }

                    val sp = applicationContext.getSharedPreferences("monitoringtb", Context.MODE_PRIVATE)
                    val editor = sp.edit()
                    editor.putString("pasien_email", email)
                    editor.commit()

                    val mainActivity = Intent(applicationContext, MainActivity::class.java)
                    startActivity(mainActivity)
                    finish()
                }else{
                    runOnUiThread {
                        Toast.makeText(applicationContext, "Email atau password tidak tepat!", Toast.LENGTH_SHORT).show()
                    }
                }
            }

        })
    }
}
